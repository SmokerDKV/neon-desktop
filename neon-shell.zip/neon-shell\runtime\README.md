# runtime/

把 **Node.js 便携版（Windows x64）** 里的 `node.exe` 放到本目录即可：

- 启动器（`启动 NEON SHELL.vbs`）会**优先**使用 `runtime/node.exe`；
- 本目录没有 `node.exe` 时，自动回退到系统 PATH 中的 `node`（需 Node 18+）；
- 下载地址：<https://nodejs.org/zh-cn/download>（选「Windows 二进制文件 (.zip)」的 64-bit）。

> 该文件约 84MB，因此**不随仓库分发**（GitHub 单文件上限 100MB），已在 `.gitignore` 中排除。
