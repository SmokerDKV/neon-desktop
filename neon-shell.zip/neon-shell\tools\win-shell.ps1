# NEON SHELL 窗口辅助脚本
# 职责：隐藏/恢复 Windows 任务栏、调整外壳窗口层级、启动应用并把它提到最前
# 参数全部通过环境变量传入，避免中文路径的引号/编码问题
$ErrorActionPreference = 'SilentlyContinue'

$Mode       = $env:NEON_MODE              # prepare | restore | launch | kill-edge
$ShellPid   = [int]$env:NEON_SHELL_PID
$Target     = $env:NEON_TARGET
$IsDir      = ($env:NEON_ISDIR -eq '1')
$ProfileDir = $env:NEON_PROFILE
$WaitSec    = if ($env:NEON_WAIT) { [int]$env:NEON_WAIT } else { 15 }

Add-Type @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

public class NSWin {
  public delegate bool EnumProc(IntPtr hWnd, IntPtr lParam);

  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr lp);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string cls, string win);
  [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int idx);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);

  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }

  static readonly IntPtr HWND_TOPMOST   = new IntPtr(-1);
  static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);
  const uint SWP_NOSIZE = 0x1, SWP_NOMOVE = 0x2, SWP_NOACTIVATE = 0x10;

  public static List<IntPtr> AllVisible() {
    var res = new List<IntPtr>();
    EnumWindows((h, lp) => { if (IsWindowVisible(h)) res.Add(h); return true; }, IntPtr.Zero);
    return res;
  }
  public static List<IntPtr> WindowsOfPid(int pid) {
    var res = new List<IntPtr>();
    EnumWindows((h, lp) => {
      uint p; GetWindowThreadProcessId(h, out p);
      if ((int)p == pid && IsWindowVisible(h)) res.Add(h);
      return true;
    }, IntPtr.Zero);
    return res;
  }
  public static string Cls(IntPtr h)      { var sb = new StringBuilder(256); GetClassName(h, sb, 256); return sb.ToString(); }
  public static string Text(IntPtr h)     { var sb = new StringBuilder(512); GetWindowText(h, sb, 512); return sb.ToString(); }
  public static bool IsTopmost(IntPtr h)  { return (GetWindowLong(h, -20) & 0x8) != 0; }
  public static long Area(IntPtr h) {
    RECT r; if (!GetWindowRect(h, out r)) return 0;
    long w = r.R - r.L, hh = r.B - r.T;
    if (w <= 0 || hh <= 0) return 0;
    return w * hh;
  }
  public static void ClearTopmost(IntPtr h) { SetWindowPos(h, HWND_NOTOPMOST, 0,0,0,0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE); }
  public static void MakeTopmost(IntPtr h)  { SetWindowPos(h, HWND_TOPMOST,   0,0,0,0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE); }
  public static void Activate(IntPtr h)     { ShowWindow(h, 9); SetForegroundWindow(h); }
}
"@

function Get-ProfilePids {
  $r = @()
  if ($ProfileDir) {
    $r = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" |
          Where-Object { $_.CommandLine -like ('*' + $ProfileDir + '*') } |
          Select-Object -ExpandProperty ProcessId)
  }
  if ($ShellPid -gt 0) { $r += $ShellPid }
  return ($r | Sort-Object -Unique)
}

function Hide-Taskbar {
  $found = 0
  foreach ($n in @('Shell_TrayWnd','Shell_SecondaryTrayWnd')) {
    $h = [NSWin]::FindWindow($n, $null)
    if ($h -ne [IntPtr]::Zero) { [void][NSWin]::ShowWindow($h, 0); $found++ }   # SW_HIDE
  }
  return $found
}
function Show-Taskbar {
  $found = 0
  foreach ($n in @('Shell_TrayWnd','Shell_SecondaryTrayWnd')) {
    $h = [NSWin]::FindWindow($n, $null)
    if ($h -ne [IntPtr]::Zero) { [void][NSWin]::ShowWindow($h, 5); $found++ }   # SW_SHOW
  }
  return $found
}

switch ($Mode) {

  'prepare' {
    # 先恢复一次，避免上次异常退出残留隐藏状态
    [void](Show-Taskbar)
    Start-Sleep -Milliseconds 120
    $hidden = Hide-Taskbar
    # 外壳窗口取消置顶：这样普通应用（及其子对话框）才能显示在外壳之上
    $cleared = 0
    foreach ($p in (Get-ProfilePids)) {
      foreach ($h in [NSWin]::WindowsOfPid([int]$p)) {
        if ([NSWin]::IsTopmost($h)) { [NSWin]::ClearTopmost($h); $cleared++ }
      }
    }
    # 让外壳窗口保持前台，保证后续启动的子进程拥有前台权限
    if ($ShellPid -gt 0) {
      $ws = [NSWin]::WindowsOfPid($ShellPid)
      foreach ($h in $ws) { [NSWin]::Activate($h) }
    }
    Write-Output ('OK taskbar=hidden found=' + $hidden + ' untopmost=' + $cleared)
  }

  'restore' {
    $shown = Show-Taskbar
    Write-Output ('OK taskbar=shown found=' + $shown)
  }

  'kill-edge' {
    $killed = @()
    foreach ($p in (Get-ProfilePids)) {
      try { Stop-Process -Id ([int]$p) -Force -ErrorAction Stop; $killed += $p } catch {}
    }
    Write-Output ('OK killed=' + ($killed -join ','))
  }

  'launch' {
    if (-not $Target) { Write-Output 'FAIL no target'; exit 1 }

    # 启动前记录已有窗口，稍后用"新出现的窗口"来定位目标
    $before = @{}
    foreach ($h in [NSWin]::AllVisible()) { $before[[int64]$h] = $true }

    # 三级降级启动：Start-Process -> ShellExecute -> cmd start
    # （部分快捷方式会让 Start-Process 抛「无法完全运行此命令…」，需要兜底）
    $proc = $null
    $started = $false
    try {
      if ($IsDir) {
        $proc = Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $Target + '"') -PassThru -ErrorAction Stop
      } else {
        $proc = Start-Process -FilePath $Target -PassThru -ErrorAction Stop
      }
      $started = $true
    } catch {}

    if (-not $started) {
      try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName        = $Target
        $psi.UseShellExecute = $true
        $proc = [System.Diagnostics.Process]::Start($psi)
        $started = $true
      } catch {}
    }
    if (-not $started) {
      try {
        Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', 'start', '""', ('"' + $Target + '"') `
                      -WindowStyle Hidden -ErrorAction Stop
        $started = $true
      } catch { Write-Output ('FAIL start: ' + $_.Exception.Message); exit 1 }
    }
    $tpid = if ($proc) { [int]$proc.Id } else { 0 }

    # 收集目标进程及其子进程
    $pids = @()
    if ($tpid -gt 0) { $pids += $tpid }
    $all = @(Get-CimInstance Win32_Process | Select-Object ProcessId, ParentProcessId, Name)
    $changed = $true; $guard = 0
    while ($changed -and $guard -lt 6) {
      $changed = $false; $guard++
      foreach ($p in $all) {
        if ($pids -contains [int]$p.ParentProcessId -and -not ($pids -contains [int]$p.ProcessId)) {
          $pids += [int]$p.ProcessId; $changed = $true
        }
      }
    }

    $hit = [IntPtr]::Zero
    $deadline = (Get-Date).AddSeconds($WaitSec)
    while ((Get-Date) -lt $deadline -and $hit -eq [IntPtr]::Zero) {
      $cands = @()
      if ($pids.Count -gt 0) {
        foreach ($p in $pids) {
          foreach ($h in [NSWin]::WindowsOfPid($p)) {
            if ([NSWin]::Area($h) -gt 4000) { $cands += $h }
          }
        }
      }
      if ($cands.Count -eq 0) {
        # 兜底：任何"新出现"的可见窗口
        foreach ($h in [NSWin]::AllVisible()) {
          if (-not $before.ContainsKey([int64]$h)) {
            $c = [NSWin]::Cls($h)
            if ($c -notlike 'Shell_*' -and $c -notlike 'Chrome_WidgetWin*' -and [NSWin]::Area($h) -gt 4000) { $cands += $h }
          }
        }
      }
      if ($cands.Count -gt 0) {
        $hit = $cands[0]
        $best = 0
        foreach ($h in $cands) { if ([NSWin]::Area($h) -gt $best) { $best = [NSWin]::Area($h); $hit = $h } }
      } elseif ((Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 350 }
    }

    if ($hit -ne [IntPtr]::Zero) {
      [NSWin]::Activate($hit)
      Start-Sleep -Milliseconds 120
      Write-Output ('OK pid=' + $tpid + ' hwnd=' + ([int64]$hit) + ' win=' + [NSWin]::Cls($hit))
    } else {
      # 没抓到窗口（可能是已有实例被激活）——退回到"激活同名前缀进程的窗口"
      if ($tpid -gt 0) {
        $rest = @(Get-CimInstance Win32_Process -Filter "ProcessId=$tpid" | Select-Object -ExpandProperty Name)
        if ($rest.Count -gt 0) {
          foreach ($p in @(Get-Process -Name ([IO.Path]::GetFileNameWithoutExtension($rest[0])) -ErrorAction SilentlyContinue)) {
            if ($p.MainWindowHandle -ne 0) { [NSWin]::Activate($p.MainWindowHandle); Write-Output ('OK pid=' + $p.Id + ' hwnd=' + $p.MainWindowHandle + ' via=name'); exit 0 }
          }
        }
      }
      Write-Output ('OK pid=' + $tpid + ' hwnd=0 (未捕获窗口，应用可能已在运行)')
    }
  }

  default { Write-Output 'FAIL unknown mode' }
}
