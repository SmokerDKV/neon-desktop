# NEON SHELL - shell / file operation daemon (persistent, STA)
# Gives the shell the same file verbs Windows Explorer offers: cut / copy /
# paste / delete(to Recycle Bin) / rename / properties / "open with".
# Clipboard work needs an STA thread, and powershell.exe is STA by default
# (server.js also passes -STA explicitly), so Clipboard::* works directly.
# Protocol: one request JSON per line  ->  one response JSON per line.
# Emits "READY <port>" on stdout once the listener is up.

[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName Microsoft.VisualBasic

$port = [int]$env:NEON_SHELL_PORT
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
$listener.Start()
[Console]::Out.WriteLine('READY ' + $port)
[Console]::Out.Flush()

$client = $listener.AcceptTcpClient()
$stream = $client.GetStream()
$reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
$writer = New-Object System.IO.StreamWriter($stream, (New-Object System.Text.UTF8Encoding($false)))
$writer.AutoFlush = $true

# Preferred DropEffect values, same numbers Explorer writes into the clipboard.
$DROPEFFECT_COPY = 5
$DROPEFFECT_MOVE = 2
# Shell copy flags: SILENT | NOCONFIRMATION | NOCONFIRMMKDIR | NOERRORUI
$FOF_FLAGS = 1556

function Get-StrList($raw) {
    $out = @()
    if ($null -eq $raw) { return $out }
    foreach ($x in @($raw)) { $s = [string]$x; if ($s.Trim().Length -gt 0) { $out += $s } }
    return $out
}

# The Windows clipboard is a single global lock: any other process that has it
# open (clipboard managers, IMEs, Explorer itself) makes our call fail with
# CLIPBRD_E_CANT_OPEN. Every access therefore goes through a short retry loop.
function Get-ClipObject {
    for ($i = 0; $i -lt 15; $i++) {
        try { return [System.Windows.Forms.Clipboard]::GetDataObject() } catch { Start-Sleep -Milliseconds 120 }
    }
    return $null
}
function Test-ClipHasFiles {
    for ($i = 0; $i -lt 15; $i++) {
        try { return [System.Windows.Forms.Clipboard]::ContainsFileDropList() } catch { Start-Sleep -Milliseconds 120 }
    }
    return $false
}
function Get-ClipFiles {
    for ($i = 0; $i -lt 15; $i++) {
        try { return [System.Windows.Forms.Clipboard]::GetFileDropList() } catch { Start-Sleep -Milliseconds 120 }
    }
    return $null
}

function Get-ClipEffects {
    # returns @{ move = $bool }
    $move = $false
    try {
        $o = Get-ClipObject
        if ($o -ne $null) {
            $d = $o.GetData('Preferred DropEffect')
            $bytes = $null
            if ($d -is [System.IO.MemoryStream]) {
                $bytes = ([System.IO.MemoryStream]$d).ToArray()
            } elseif ($d -is [byte[]]) {
                $bytes = $d
            }
            if ($bytes -ne $null -and $bytes.Length -ge 4) {
                $v = [BitConverter]::ToInt32($bytes, 0)
                $move = (($v -band $DROPEFFECT_MOVE) -ne 0)
            }
        }
    } catch {}
    return @{ move = $move }
}

function Set-ClipboardFiles([string[]]$paths, [bool]$cut) {
    $col = New-Object System.Collections.Specialized.StringCollection
    foreach ($p in $paths) { if (Test-Path -LiteralPath $p) { [void]$col.Add($p) } }
    if ($col.Count -eq 0) { return @{ ok = $false; err = '没有可用的文件' } }

    $data = New-Object System.Windows.Forms.DataObject
    $data.SetFileDropList($col)

    $eff = $DROPEFFECT_COPY
    if ($cut) { $eff = $DROPEFFECT_MOVE }
    $ms = New-Object System.IO.MemoryStream
    $b  = [BitConverter]::GetBytes([int]$eff)
    $ms.Write($b, 0, 4)
    $ms.Position = 0
    $data.SetData('Preferred DropEffect', $ms)

    $ok = $false; $lastErr = ''
    for ($i = 0; $i -lt 15; $i++) {
        try {
            [System.Windows.Forms.Clipboard]::SetDataObject($data, $true, 8, 120)
            $ok = $true; break
        } catch { $lastErr = $_.Exception.Message; Start-Sleep -Milliseconds 150 }
    }
    if (-not $ok) { return @{ ok = $false; err = ('剪贴板被其他程序占用：' + $lastErr) } }
    return @{ ok = $true; count = $col.Count; eff = $eff; cut = $cut }
}

function Get-ClipInfo {
    $res = @{ ok = $true; has = $false; count = 0; names = @(); move = $false }
    try {
        if (-not (Test-ClipHasFiles)) { return $res }
        $col = Get-ClipFiles
        if ($null -eq $col) { return $res }
        $names = @()
        foreach ($f in $col) {
            if ($names.Count -ge 4) { break }
            try { $names += (Split-Path -Leaf $f) } catch {}
        }
        $eff = Get-ClipEffects
        $res.has = $true
        $res.count = $col.Count
        $res.names = $names
        $res.move = $eff.move
    } catch {}
    return $res
}

function Invoke-Paste([string]$target) {
    if (-not $target -or -not (Test-Path -LiteralPath $target)) {
        return @{ ok = $false; err = '目标目录不存在' }
    }
    if (-not (Test-ClipHasFiles)) {
        return @{ ok = $false; err = '剪贴板里没有文件（或无法访问剪贴板）' }
    }
    $col = Get-ClipFiles
    if ($null -eq $col -or $col.Count -eq 0) { return @{ ok = $false; err = '剪贴板里没有文件' } }
    $eff  = Get-ClipEffects
    $move = $eff.move

    $sh  = New-Object -ComObject Shell.Application
    $dst = $sh.NameSpace($target)
    if ($null -eq $dst) { return @{ ok = $false; err = '无法访问目标目录' } }

    $n = 0; $errs = @()
    foreach ($f in $col) {
        if (-not $f) { continue }
        try {
            if ($move) { $dst.MoveHere($f, $FOF_FLAGS) } else { $dst.CopyHere($f, $FOF_FLAGS) }
            $n++
        } catch { $errs += $_.Exception.Message }
    }
    return @{ ok = ($n -gt 0); count = $n; move = $move; err = ($errs -join ' | ') }
}

function Invoke-Delete([string[]]$paths) {
    $n = 0; $errs = @()
    foreach ($p in $paths) {
        if (-not (Test-Path -LiteralPath $p)) { continue }
        try {
            if (Test-Path -LiteralPath $p -PathType Container) {
                [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($p, 'OnlyErrorDialogs', 'SendToRecycleBin')
            } else {
                [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($p, 'OnlyErrorDialogs', 'SendToRecycleBin')
            }
            $n++
        } catch {
            # SHFileOperation sometimes reports a failure even after the item has
            # already landed in the Recycle Bin - trust the file system instead.
            if (Test-Path -LiteralPath $p) { $errs += $_.Exception.Message } else { $n++ }
        }
    }
    return @{ ok = ($n -gt 0); count = $n; err = ($errs -join ' | ') }
}

function Invoke-Rename([string]$p, [string]$name) {
    if (-not $p -or -not (Test-Path -LiteralPath $p)) { return @{ ok = $false; err = '文件不存在' } }
    $name = ([string]$name).Trim()
    if ($name.Length -eq 0) { return @{ ok = $false; err = '名称不能为空' } }
    if ($name.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0) {
        return @{ ok = $false; err = '名称含有非法字符 \ / : * ? " < > |' }
    }
    $parent = Split-Path -Parent $p
    $dest   = Join-Path $parent $name
    if ($dest -eq $p) { return @{ ok = $true; path = $p; name = $name } }
    if (Test-Path -LiteralPath $dest) { return @{ ok = $false; err = '已存在同名项目' } }
    Rename-Item -LiteralPath $p -NewName $name -ErrorAction Stop
    return @{ ok = $true; path = $dest; name = $name }
}

function Invoke-Props([string]$p) {
    if (-not (Test-Path -LiteralPath $p)) { return @{ ok = $false; err = '文件不存在' } }
    $parent = Split-Path -Parent $p
    $leaf   = Split-Path -Leaf $p
    $sh = New-Object -ComObject Shell.Application
    $item = $sh.NameSpace($parent).ParseName($leaf)
    if ($null -eq $item) { return @{ ok = $false; err = '无法获取 Shell 项目' } }
    $item.InvokeVerb('Properties')
    return @{ ok = $true }
}

function Invoke-OpenWith([string]$p) {
    if (-not (Test-Path -LiteralPath $p)) { return @{ ok = $false; err = '文件不存在' } }
    Start-Process -FilePath 'rundll32.exe' -ArgumentList 'shell32.dll,OpenAs_RunDLL', ('"' + $p + '"')
    return @{ ok = $true }
}

while ($true) {
    $line = $reader.ReadLine()
    if ($line -eq $null) { break }
    if ($line.Trim().Length -eq 0) { continue }

    $req = $null
    try { $req = ConvertFrom-Json $line } catch { continue }

    $id = 0
    try { $id = [int]$req.id } catch {}
    $op = [string]$req.op

    try {
        switch ($op) {
            'ping'    { $resp = @{ id = $id; ok = $true; pong = $true; sta = ([System.Threading.Thread]::CurrentThread.GetApartmentState().ToString()) } }
            'clipinfo'{ $r = Get-ClipInfo; $resp = @{ id = $id; ok = $r.ok; has = $r.has; count = $r.count; names = $r.names; move = $r.move } }
            'copy'    { $r = Set-ClipboardFiles (Get-StrList $req.paths) $false; $resp = @{ id = $id; ok = $r.ok; count = $r.count; eff = $r.eff; err = $r.err } }
            'cut'     { $r = Set-ClipboardFiles (Get-StrList $req.paths) $true;  $resp = @{ id = $id; ok = $r.ok; count = $r.count; eff = $r.eff; err = $r.err } }
            'paste'   {
                $t = [string]$req.target
                if (-not $t) { $t = $env:USERPROFILE + '\Desktop' }
                $r = Invoke-Paste $t
                $resp = @{ id = $id; ok = $r.ok; count = $r.count; move = $r.move; err = $r.err }
            }
            'delete'  { $r = Invoke-Delete (Get-StrList $req.paths); $resp = @{ id = $id; ok = $r.ok; count = $r.count; err = $r.err } }
            'rename'  { $r = Invoke-Rename ([string]$req.path) ([string]$req.name); $resp = @{ id = $id; ok = $r.ok; path = $r.path; name = $r.name; err = $r.err } }
            'props'   { $r = Invoke-Props ([string]$req.path); $resp = @{ id = $id; ok = $r.ok; err = $r.err } }
            'openwith'{ $r = Invoke-OpenWith ([string]$req.path); $resp = @{ id = $id; ok = $r.ok; err = $r.err } }
            default   { $resp = @{ id = $id; ok = $false; err = ('unknown op ' + $op) } }
        }
    } catch {
        $resp = @{ id = $id; ok = $false; err = $_.Exception.Message }
    }

    $clean = @{}
    foreach ($k in $resp.Keys) { if ($null -ne $resp[$k] -and ([string]$resp[$k]).Length -gt 0) { $clean[$k] = $resp[$k] } }
    if (-not $clean.ContainsKey('ok')) { $clean['ok'] = $resp['ok'] }
    $writer.WriteLine(($clean | ConvertTo-Json -Compress -Depth 4))
}
