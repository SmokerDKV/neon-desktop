' NEON SHELL launcher - no console window, path-independent
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
node = base & "\runtime\node.exe"
If Not fso.FileExists(node) Then node = "node.exe"
Set sh = CreateObject("WScript.Shell")
sh.Run """" & node & """ """ & base & "\server.js""", 0, False
