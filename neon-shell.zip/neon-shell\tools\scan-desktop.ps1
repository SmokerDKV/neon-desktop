# NEON SHELL - Desktop scanner & icon extractor
# Pure ASCII source (PowerShell 5.1 reads UTF-8-without-BOM as ANSI).
# Emits a single JSON document on stdout.

[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$CSharp = @'
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

public static class NeonIcon
{
    const uint SHGFI_ICON          = 0x000000100;
    const uint SHGFI_SYSICONINDEX  = 0x000004000;
    const uint SHGFI_LARGEICON     = 0x000000000;
    const int  SHIL_JUMBO          = 0x4;
    const int  ILD_TRANSPARENT     = 0x1;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct SHFILEINFO
    {
        public IntPtr hIcon;
        public int    iIcon;
        public uint   dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]  public string szTypeName;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct IMAGELISTDRAWPARAMS
    {
        public int    cbSize;
        public IntPtr himl;
        public int    i;
        public IntPtr hdcDst;
        public int    x, y, cx, cy, xBitmap, yBitmap;
        public int    rgbBk, rgbFg, fStyle, dwRop;
    }

    [ComImport, Guid("46EB5926-582E-4017-9FDF-E8998DAA0950"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IImageList
    {
        [PreserveSig] int Add(IntPtr hbmImage, IntPtr hbmMask, ref int pi);
        [PreserveSig] int ReplaceIcon(int i, IntPtr hicon, ref int pi);
        [PreserveSig] int SetOverlayImage(int iImage, int iOverlay);
        [PreserveSig] int Replace(int i, IntPtr hbmImage, IntPtr hbmMask);
        [PreserveSig] int AddMasked(IntPtr hbmImage, int crMask, ref int pi);
        [PreserveSig] int Draw(ref IMAGELISTDRAWPARAMS pimldp);
        [PreserveSig] int Remove(int i);
        [PreserveSig] int GetIcon(int i, int flags, ref IntPtr picon);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    static extern IntPtr SHGetFileInfo(string pszPath, uint dwFileAttributes, ref SHFILEINFO psfi, uint cbFileInfo, uint uFlags);

    [DllImport("shell32.dll")]
    static extern int SHGetImageList(int iImageList, ref Guid riid, out IImageList ppv);

    [DllImport("user32.dll")]
    static extern bool DestroyIcon(IntPtr hIcon);

    public static string Extract(string path, string outPng, int size, out int gotW, out int gotH)
    {
        gotW = 0; gotH = 0;
        IntPtr hIcon = IntPtr.Zero;
        IImageList list = null;
        string src = "?";
        try
        {
            var shfi = new SHFILEINFO();
            IntPtr ret = SHGetFileInfo(path, 0, ref shfi, (uint)Marshal.SizeOf(typeof(SHFILEINFO)),
                                       SHGFI_SYSICONINDEX | SHGFI_LARGEICON);
            if (ret == IntPtr.Zero) return "SHGETFILEINFO_ZERO";

            Guid iid = new Guid("46EB5926-582E-4017-9FDF-E8998DAA0950");
            int hr = SHGetImageList(SHIL_JUMBO, ref iid, out list);
            if (hr == 0 && list != null)
            {
                if (list.GetIcon(shfi.iIcon, ILD_TRANSPARENT, ref hIcon) == 0 && hIcon != IntPtr.Zero)
                    src = "jumbo";
            }
            if (hIcon == IntPtr.Zero)
            {
                var f2 = new SHFILEINFO();
                SHGetFileInfo(path, 0, ref f2, (uint)Marshal.SizeOf(typeof(SHFILEINFO)), SHGFI_ICON | SHGFI_LARGEICON);
                hIcon = f2.hIcon;
                src = "large";
            }
            if (hIcon == IntPtr.Zero) return "NO_ICON";

            using (var ico = Icon.FromHandle(hIcon))
            {
                gotW = ico.Width; gotH = ico.Height;
                using (var bmp = new Bitmap(size, size, PixelFormat.Format32bppArgb))
                {
                    using (var g = Graphics.FromImage(bmp))
                    {
                        g.Clear(Color.Transparent);
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.PixelOffsetMode   = PixelOffsetMode.HighQuality;
                        g.DrawIcon(ico, new Rectangle(0, 0, size, size));
                    }
                    bmp.Save(outPng, ImageFormat.Png);
                }
            }
            return "OK:" + src;
        }
        catch (Exception ex) { return "ERR:" + ex.Message; }
        finally
        {
            if (hIcon != IntPtr.Zero) { try { DestroyIcon(hIcon); } catch {} }
            if (list  != null)        { try { Marshal.ReleaseComObject(list); } catch {} }
        }
    }
}
'@

Add-Type -TypeDefinition $CSharp -ReferencedAssemblies 'System.Drawing' -ErrorAction Stop

$OUT_DIR = Join-Path $env:LOCALAPPDATA 'NeonShell\icons'
if (-not (Test-Path -LiteralPath $OUT_DIR)) { New-Item -ItemType Directory -Force -Path $OUT_DIR | Out-Null }
$INDEX_FILE = Join-Path $env:LOCALAPPDATA 'NeonShell\icon-index.json'

$cache = @{}
if (Test-Path -LiteralPath $INDEX_FILE) {
    try {
        $raw = Get-Content -LiteralPath $INDEX_FILE -Raw -Encoding UTF8
        if ($raw) {
            (ConvertFrom-Json $raw).PSObject.Properties | ForEach-Object { $cache[$_.Name] = $_.Value }
        }
    } catch { $cache = @{} }
}

function Get-IconHash([string]$p) {
    $fi = New-Item -ItemType File -Path $p -Force -ErrorAction SilentlyContinue
    return $null
}

$roots = @()
$roots += [Environment]::GetFolderPath('Desktop')
$pub = [Environment]::GetFolderPath('CommonDesktopDirectory')
if ($pub) { $roots += $pub }
$roots = $roots | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

$skip = @('desktop.ini', 'thumbs.db', '.ds_store')

$items = New-Object System.Collections.ArrayList
$newCache = @{}
$seen = @{}

foreach ($root in $roots) {
    $files = Get-ChildItem -LiteralPath $root -Force -ErrorAction SilentlyContinue
    foreach ($f in $files) {
        if ($skip -contains $f.Name.ToLower()) { continue }
        if ($f.Attributes -band [IO.FileAttributes]::Hidden) { continue }
        $full = $f.FullName
        if ($seen.ContainsKey($full)) { continue }
        $seen[$full] = $true

        $isDir = $f.PSIsContainer
        $ext = ''
        if (-not $isDir) { $ext = $f.Extension.ToLower() }

        $kind = 'file'
        if ($isDir)                      { $kind = 'folder' }
        elseif ($ext -eq '.lnk')         { $kind = 'link' }
        elseif ($ext -eq '.url')         { $kind = 'url' }
        elseif ($ext -eq '.exe')         { $kind = 'exe' }
        elseif ($ext -eq '.bat' -or $ext -eq '.cmd' -or $ext -eq '.ps1') { $kind = 'script' }
        elseif ($ext -in @('.png','.jpg','.jpeg','.gif','.bmp','.webp','.svg','.ico')) { $kind = 'image' }
        elseif ($ext -in @('.doc','.docx','.pdf','.txt','.md','.rtf','.xls','.xlsx','.ppt','.pptx')) { $kind = 'doc' }
        elseif ($ext -in @('.zip','.rar','.7z','.tar','.gz')) { $kind = 'archive' }

        $label = $f.BaseName
        if ($isDir) { $label = $f.Name }
        if ($ext -in @('.lnk','.url')) { $label = $f.BaseName }

        $key = ($f.LastWriteTimeUtc.Ticks.ToString() + '_' + $f.Length.ToString())
        $png = $null
        $src = '-'

        $cached = $cache[$full]
        if ($cached -and $cached.k -eq $key -and (Test-Path -LiteralPath (Join-Path $OUT_DIR $cached.f))) {
            $png = $cached.f
            $src = 'cache'
        } else {
            $safe = [Guid]::NewGuid().ToString('N') + '.png'
            $dest = Join-Path $OUT_DIR $safe
            $w = 0; $h = 0
            $res = [NeonIcon]::Extract($full, $dest, 128, [ref]$w, [ref]$h)
            if ($res -like 'OK*') {
                $png = $safe
                $src = $res + '(' + $w + 'x' + $h + ')'
            } else {
                $src = $res
            }
        }
        if ($png) { $newCache[$full] = @{ k = $key; f = $png } }

        $null = $items.Add([ordered]@{
            name    = $label
            raw     = $f.Name
            path    = $full
            kind    = $kind
            ext     = $ext
            isDir   = [bool]$isDir
            size    = [int64]($(if ($isDir) { 0 } else { $f.Length }))
            mtime   = $f.LastWriteTimeUtc.ToString('o')
            icon    = $png
            iconSrc = $src
            source  = $(if ($root -eq $pub) { 'public' } else { 'user' })
        })
    }
}

$newCache | ConvertTo-Json -Depth 3 -Compress | Set-Content -LiteralPath $INDEX_FILE -Encoding UTF8

$result = [ordered]@{
    desktopPath = [Environment]::GetFolderPath('Desktop')
    user        = $env:USERNAME
    computer    = $env:COMPUTERNAME
    count       = $items.Count
    items       = @($items)
}

$json = $result | ConvertTo-Json -Depth 6 -Compress
[Console]::Out.Write($json)
