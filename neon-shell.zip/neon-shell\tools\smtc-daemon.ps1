# NEON SHELL - SMTC media daemon (persistent)
# Listens on 127.0.0.1:$env:NEON_MEDIA_PORT (loopback only).
# Line protocol: request JSON per line -> response JSON per line.
# Emits "READY <port>" on stdout when the TCP listener is up.

[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

Add-Type -AssemblyName System.Runtime.WindowsRuntime

$asTaskOp = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
$asTaskAction = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]

function Await-Op([object]$op, [type]$resultType) {
    $asTask = $asTaskOp.MakeGenericMethod($resultType)
    $t = $asTask.Invoke($null, @($op))
    if (-not $t.Wait(4000)) { throw 'async timeout' }
    return $t.Result
}
function Await-Action([object]$action) {
    $act = [Windows.Foundation.IAsyncAction]$action
    $t = $asTaskAction.Invoke($null, @($act))
    if (-not $t.Wait(4000)) { throw 'async timeout' }
}

$MT = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType=WindowsRuntime]
$PT = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType=WindowsRuntime]
$RS = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]

$mgr = $null
try { $mgr = Await-Op ($MT::RequestAsync()) $MT } catch {
    [Console]::Out.WriteLine('FATAL ' + $_.Exception.Message)
    exit 1
}
if ($mgr -eq $null) { [Console]::Out.WriteLine('FATAL manager null'); exit 1 }

$port = [int]$env:NEON_MEDIA_PORT
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
$listener.Start()
[Console]::Out.WriteLine('READY ' + $port)
[Console]::Out.Flush()

$client = $listener.AcceptTcpClient()
$stream = $client.GetStream()
$reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
$writer = New-Object System.IO.StreamWriter($stream, (New-Object System.Text.UTF8Encoding($false)))
$writer.AutoFlush = $true

$script:coverKey   = ''
$script:coverVer   = 0
$coverFile = Join-Path $env:LOCALAPPDATA 'NeonShell\cover.bin'

function Get-State {
    $out = @{ has = $false }
    try {
        $s = $mgr.GetCurrentSession()
        if ($s -ne $null) {
            $out.has   = $true
            $out.app   = $s.SourceAppUserModelId
            $p  = Await-Op ($s.TryGetMediaPropertiesAsync()) $PT
            $out.title  = $p.Title
            $out.artist = $p.Artist
            $out.album  = $p.AlbumTitle
            $pi = $s.GetPlaybackInfo()
            if ($pi -ne $null) { $out.status = [string]$pi.PlaybackStatus }
            try {
                $tl = $s.GetTimelineProperties()
                if ($tl -ne $null) {
                    $out.pos = [math]::Round($tl.Position.TotalSeconds, 1)
                    $out.dur = [math]::Round($tl.EndTime.TotalSeconds, 1)
                }
            } catch {}
            try {
                $c = $pi.Controls
                if ($c -ne $null) {
                    $out.canPlay = [bool]($c.IsPlayEnabled -or $c.IsPauseEnabled)
                    $out.canNext = [bool]$c.IsNextEnabled
                    $out.canPrev = [bool]$c.IsPreviousEnabled
                }
            } catch {}

            $key = ([string]$p.Title) + '|' + ([string]$p.Artist) + '|' + ([string]$p.AlbumTitle)
            if ($key -ne $script:coverKey) {
                if ($p.Thumbnail -ne $null) {
                    try {
                        $rs = Await-Op ($p.Thumbnail.OpenReadAsync()) $RS
                        $mime = ''
                        try { $mime = [string]$rs.ContentType } catch {}
                        $net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($rs)
                        $ms  = New-Object System.IO.MemoryStream
                        $net.CopyTo($ms)
                        [IO.File]::WriteAllBytes($coverFile, $ms.ToArray())
                        $net.Dispose(); $ms.Dispose()
                        $script:coverVer = $script:coverVer + 1
                        $out.coverMime = $mime
                        $out.coverVer  = $script:coverVer
                    } catch { $out.coverErr = $_.Exception.Message }
                }
                $script:coverKey = $key
            }
            if ($script:coverVer -gt 0) { $out.coverVer = $script:coverVer }
        }
    } catch { $out.err = $_.Exception.Message }
    return $out
}

function Invoke-Cmd([string]$op) {
    $s = $mgr.GetCurrentSession()
    if ($s -eq $null) { return @{ ok = $false; err = 'no session' } }
    # Fire-and-forget: the WinRT call takes effect immediately; the actual
    # playback state is verified through the state poll, so we don't need
    # to await the returned IAsyncAction (PS 5.1 cannot QI the __ComObject).
    switch ($op) {
        'toggle' { $null = $s.TryTogglePlayPauseAsync() }
        'next'   { $null = $s.TrySkipNextAsync() }
        'prev'   { $null = $s.TrySkipPreviousAsync() }
        'stop'   { $null = $s.TryStopAsync() }
        default  { return @{ ok = $false; err = 'unknown op ' + $op } }
    }
    return @{ ok = $true }
}

while ($true) {
    $line = $reader.ReadLine()
    if ($line -eq $null) { break }
    if ($line.Trim().Length -eq 0) { continue }
    $req = $null
    try { $req = ConvertFrom-Json $line } catch { continue }
    $id = 0
    try { $id = [int]$req.id } catch {}
    $op = [string]$req.op
    try {
        if ($op -eq 'state') {
            $resp = @{ id = $id; ok = $true; state = (Get-State) }
        } elseif ($op -eq 'ping') {
            $resp = @{ id = $id; ok = $true; pong = $true }
        } else {
            $r = Invoke-Cmd $op
            $resp = @{ id = $id; ok = $r.ok }
            if ($r.err) { $resp.err = $r.err }
        }
    } catch {
        $resp = @{ id = $id; ok = $false; err = $_.Exception.Message }
    }
    $writer.WriteLine(($resp | ConvertTo-Json -Compress -Depth 4))
}
