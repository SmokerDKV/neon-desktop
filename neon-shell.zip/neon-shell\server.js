'use strict';
/* ============================================================
 * NEON SHELL - desktop shell backend (zero-dependency Node)
 *  - scans the real Windows desktop (links / folders / files)
 *  - serves the shell UI over http://127.0.0.1 (secure context)
 *  - bridges SMTC media sessions       (tools/smtc-daemon.ps1)
 *  - bridges window mgmt + launch      (tools/win-daemon.ps1)
 *  - mirrors the current Lively Wallpaper as an in-shell layer
 *  - launches a dedicated Edge kiosk window (fullscreen shell)
 * ============================================================ */
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'NeonShell');
const ICON_DIR = path.join(DATA_DIR, 'icons');
const COVER_FILE = path.join(DATA_DIR, 'cover.bin');
const LOG_FILE = path.join(DATA_DIR, 'server.log');
const EDGE_PROFILE = path.join(DATA_DIR, 'edge-profile');

// NEON_BASE_PORT lets a test instance run on its own port range without
// touching the shell the user is currently looking at.
const BASE_PORT = parseInt(process.env.NEON_BASE_PORT || '45730', 10);

/* The helper-daemon ports are DERIVED from the chosen HTTP port (port + 9 / + 10)
 * instead of being hard-coded. Fixed ports were the reason a second launch of the
 * shell ended up with dead daemons ("Only one usage of each socket address ..."):
 * the old instance still held 45739/45740, so the new one could never bind them
 * and every "open app" / taskbar call silently failed. */
let HTTP_PORT  = BASE_PORT;
let MEDIA_PORT = BASE_PORT + 9;   // SMTC daemon TCP port
let WIN_PORT   = BASE_PORT + 10;  // window daemon TCP port
let SHELL_PORT = BASE_PORT + 11;  // file / clipboard daemon TCP port
const SCAN_INTERVAL = 15e3;     // desktop re-scan cooldown (ms)
const MEDIA_POLL = 800;         // SMTC state poll (ms)

fs.mkdirSync(ICON_DIR, { recursive: true });
function log(...a) {
  const line = `[${new Date().toISOString()}] ${a.join(' ')}`;
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch (e) {}
  console.log(line);
}
process.on('uncaughtException', e => { log('UNCAUGHT', e.stack || String(e)); });
process.on('unhandledRejection', e => { log('UNHANDLED', e && e.stack || String(e)); });

/* ---------------- single instance + port pick ---------------- */
const sleep = ms => new Promise(r => setTimeout(r, ms));
function probePort(port) {
  return new Promise(res => {
    const s = net.createServer();
    s.once('error', () => res(false));
    s.once('listening', () => s.close(() => res(true)));
    s.listen(port, '127.0.0.1');
  });
}
function httpGet(port, pathname, timeout = 1500) {
  return new Promise(res => {
    const rq = http.request({ host: '127.0.0.1', port, path: pathname, method: 'GET', timeout }, resp => {
      let b = '';
      resp.on('data', d => { b += d; });
      resp.on('end', () => { try { res(JSON.parse(b)); } catch (e) { res(null); } });
    });
    rq.on('error', () => res(null));
    rq.on('timeout', () => { try { rq.destroy(); } catch (e) {} res(null); });
    rq.end();
  });
}
/* If a NEON SHELL is already alive we ask it to quit and wait for the port,
 * rather than starting a second, half-broken instance the user then stares at. */
async function ensureSingleInstance() {
  if (await probePort(BASE_PORT)) return;
  const info = await httpGet(BASE_PORT, '/api/ping');
  if (!info || info.app !== 'neon-shell') {
    log('port', BASE_PORT, 'taken by something else - will use the next free port');
    return;
  }
  log('another NEON SHELL is running - asking it to quit');
  await httpGet(BASE_PORT, '/api/exit', 2500);
  for (let i = 0; i < 60; i++) { if (await probePort(BASE_PORT)) { log('previous instance released the port'); return; } await sleep(150); }
  log('previous instance did not release the port - will use the next free port');
}
async function pickPort() {
  for (let p = BASE_PORT; p < BASE_PORT + 20; p++) {
    if (await probePort(p)) return p;
    if (p === BASE_PORT) log('port', p, 'busy');
  }
  throw new Error('no free port');
}
/* Orphaned daemons (parent Node killed with /F) can keep holding our helper
 * ports. Kill the ones that are actually running our scripts before starting. */
function freeDaemonPorts() {
  const ps = `
$ports = @(${MEDIA_PORT}, ${WIN_PORT}, ${SHELL_PORT})
foreach($p in $ports){
  try{
    Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
      $proc = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $_.OwningProcess) -ErrorAction SilentlyContinue
      if($proc -and $proc.CommandLine -and ($proc.CommandLine -match 'smtc-daemon\\.ps1|win-daemon\\.ps1|shell-daemon\\.ps1')){
        Stop-Process -Id $proc.ProcessId -Force -ErrorAction SilentlyContinue
      }
    }
  }catch{}
}
`;
  try {
    const b64 = Buffer.from(ps, 'utf16le').toString('base64');
    spawnSync('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', b64],
      { stdio: ['ignore', 'pipe', 'pipe'], timeout: 15000, windowsHide: true });
  } catch (e) { log('freeDaemonPorts failed:', (e && e.message) || e); }
}

/* ---------------- desktop scan ---------------- */
let desktop = { items: [], desktopPath: '', ts: 0 };
let scanning = false;
function scanDesktop() {
  if (scanning) return;
  scanning = true;
  const t0 = Date.now();
  try {
    const script = fs.readFileSync(path.join(ROOT, 'tools', 'scan-desktop.ps1'), 'utf8');
    const b64 = Buffer.from(script, 'utf16le').toString('base64');
    const r = spawnSync('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', b64],
      { encoding: 'buffer', stdio: ['ignore', 'pipe', 'pipe'], timeout: 180000, windowsHide: true });
    const out = r.stdout ? r.stdout.toString('utf8').trim() : '';
    const data = JSON.parse(out);
    const rank = { folder: 0, link: 1, exe: 2, url: 3, doc: 4, image: 4, archive: 4, script: 4, file: 5 };
    data.items.sort((a, b) =>
      (rank[a.kind] ?? 4) - (rank[b.kind] ?? 4) ||
      a.name.localeCompare(b.name, 'zh-Hans-CN'));
    for (const it of data.items) it.iconUrl = it.icon ? ('/icon/' + it.icon) : null;
    desktop = { items: data.items, desktopPath: data.desktopPath, ts: Date.now() };
    log('desktop scan ok:', data.items.length, 'items in', Date.now() - t0, 'ms');
  } catch (e) {
    log('desktop scan FAILED:', (e && e.message) || e,
      (e && e.stderr && String(e.stderr).slice(0, 300)) || '');
  } finally { scanning = false; }
}

/* ============================================================
 * Persistent PowerShell daemons (line protocol over loopback TCP)
 * Starting PowerShell + compiling C# costs ~0.5-2s, so we keep one
 * process alive and talk to it instead of spawning per action.
 * ============================================================ */
function writePs1(name, content) {
  const p = path.join(DATA_DIR, name);
  fs.writeFileSync(p, '\ufeff' + content, 'utf8');   // BOM: PS 5.1 reads UTF-8 correctly
  return p;
}

function makeDaemonBridge(cfg) {
  const st = { child: null, sock: null, ready: false, restarts: 0, reqId: 0, pending: new Map(), buf: '' };
  function start() {
    if (st.restarts > 8) { log(cfg.name + ' daemon: giving up after repeated failures'); return; }
    st.ready = false;
    const p = writePs1(cfg.scriptFile, fs.readFileSync(path.join(ROOT, 'tools', cfg.src), 'utf8'));
    st.child = spawn('powershell.exe',
      ['-NoProfile', '-NonInteractive'].concat(cfg.args || []).concat(['-ExecutionPolicy', 'Bypass', '-File', p]),
      { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true, env: Object.assign({}, process.env, cfg.env()) });

    st.buf = '';
    st.child.stdout.on('data', d => {
      st.buf += d.toString('utf8');
      let i;
      while ((i = st.buf.indexOf('\n')) >= 0) {
        const line = st.buf.slice(0, i).trim(); st.buf = st.buf.slice(i + 1);
        if (!line) continue;
        if (line.startsWith('READY')) {
          st.ready = true; st.restarts = 0;
          connect();
          log(cfg.name + ' daemon ready');
        } else if (line.startsWith('FATAL')) {
          log(cfg.name + ' daemon FATAL:', line);
        }
      }
    });
    st.child.stderr.on('data', d => log(cfg.name + ' daemon stderr:', d.toString('utf8').slice(0, 300)));
    st.child.on('exit', code => {
      log(cfg.name + ' daemon exited:', code);
      st.sock = null; st.ready = false;
      if (shuttingDown) return;
      st.restarts++;
      setTimeout(start, Math.min(2000 * st.restarts, 15000));
    });
  }
  function connect() {
    const s = net.connect(cfg.port(), '127.0.0.1');
    let rb = '';
    s.on('connect', () => log(cfg.name + ' bridge connected'));
    s.on('data', d => {
      rb += d.toString('utf8');
      let j;
      while ((j = rb.indexOf('\n')) >= 0) {
        const line = rb.slice(0, j).trim(); rb = rb.slice(j + 1);
        if (!line) continue;
        try {
          const msg = JSON.parse(line);
          const p = st.pending.get(msg.id);
          if (p) { st.pending.delete(msg.id); p(msg); }
        } catch (e) {}
      }
    });
    s.on('error', e => log(cfg.name + ' bridge error:', e.message));
    s.on('close', () => { st.sock = null; });
    st.sock = s;
  }
  function send(op, extra, timeoutMs) {
    timeoutMs = timeoutMs || 8000;
    return new Promise(res => {
      if (!st.sock || !st.ready) return res({ ok: false, err: 'daemon not ready' });
      const id = ++st.reqId;
      st.pending.set(id, res);
      try { st.sock.write(JSON.stringify(Object.assign({ id, op }, extra || {})) + '\n'); }
      catch (e) { st.pending.delete(id); return res({ ok: false, err: e.message }); }
      setTimeout(() => {
        if (st.pending.has(id)) { st.pending.delete(id); res({ ok: false, err: 'timeout' }); }
      }, timeoutMs);
    });
  }
  function waitReady(ms) {
    if (st.ready) return Promise.resolve(true);
    return new Promise(res => {
      const t0 = Date.now();
      const iv = setInterval(() => {
        if (st.ready) { clearInterval(iv); res(true); }
        else if (Date.now() - t0 > (ms || 15000)) { clearInterval(iv); res(false); }
      }, 120);
    });
  }
  function kill() { try { if (st.child) st.child.kill(); } catch (e) {} }
  /* Self-heal: if the daemon process died we start a fresh one on demand. */
  function revive() {
    if (st.child && st.child.exitCode === null && st.child.signalCode === null) return;
    st.restarts = 0;
    start();
  }
  return { st, start, send, waitReady, kill, revive };
}

let shuttingDown = false;

/* ---------------- SMTC media bridge ---------------- */
let mediaState = { has: false };
const media = makeDaemonBridge({
  name: 'media', src: 'smtc-daemon.ps1', scriptFile: 'smtc-daemon.ps1', port: () => MEDIA_PORT,
  env: () => ({ NEON_MEDIA_PORT: String(MEDIA_PORT) })
});

async function mediaPollLoop() {
  for (;;) {
    if (media.st.ready && media.st.sock) {
      const r = await media.send('state', {}, 5000);
      if (r && r.ok && r.state) mediaState = r.state;
    }
    await new Promise(r => setTimeout(r, MEDIA_POLL));
  }
}

/* ---------------- window / launch bridge ---------------- */
const win = makeDaemonBridge({
  name: 'win', src: 'win-daemon.ps1', scriptFile: 'win-daemon.ps1', port: () => WIN_PORT,
  env: () => ({ NEON_WIN_PORT: String(WIN_PORT), NEON_PROFILE: EDGE_PROFILE,
                NEON_SHELL_PID: String(edgeChild ? edgeChild.pid : 0) })
});

/* ---------------- file / clipboard bridge (Explorer-like verbs) ---------------- */
const shell = makeDaemonBridge({
  name: 'shell', src: 'shell-daemon.ps1', scriptFile: 'shell-daemon.ps1', port: () => SHELL_PORT,
  args: ['-STA'],                  // clipboard needs a single-threaded apartment
  env: () => ({ NEON_SHELL_PORT: String(SHELL_PORT) })
});

const iconCache = new Map();      // exe/class key -> icon filename | null
function iconFileFor(key) { return crypto.createHash('md5').update(key).digest('hex') + '.png'; }

async function ensureIcon(exe, cls) {
  const key = (exe && exe.toLowerCase()) || ('cls:' + (cls || 'x'));
  if (iconCache.has(key)) return iconCache.get(key);
  const name = iconFileFor(key);
  const out = path.join(ICON_DIR, name);
  if (fs.existsSync(out)) { iconCache.set(key, name); return name; }
  if (!exe) { iconCache.set(key, null); return null; }
  const r = await win.send('icon', { path: exe, out }, 8000);
  if (r && r.ok && fs.existsSync(out)) { iconCache.set(key, name); return name; }
  iconCache.set(key, null);
  return null;
}

async function winListWithIcons() {
  const r = await win.send('winlist', {}, 6000);
  if (!r || !r.ok || !Array.isArray(r.wins)) return { ok: false, wins: [] };
  const wins = [];
  for (const w of r.wins) {
    const icon = await ensureIcon(w.exe, w.c);
    wins.push({ h: w.h, pid: w.pid, t: w.t, c: w.c, min: w.min, max: w.max,
                exe: w.exe || '', icon: icon || null,
                iconUrl: icon ? ('/icon/' + icon) : null });
  }
  return { ok: true, wins };
}

/* ---------------- system stats ---------------- */
let cpuSample = os.cpus().map(c => c.times);
let cpuPct = 0;
setInterval(() => {
  const now = os.cpus().map(c => c.times);
  let idle = 0, total = 0;
  now.forEach((t, i) => {
    const p = cpuSample[i];
    const d = t.user - p.user + t.nice - p.nice + t.sys - p.sys + t.idle - p.idle + t.irq - p.irq;
    total += d; idle += t.idle - p.idle;
  });
  if (total > 0) cpuPct = Math.max(0, Math.min(100, (1 - idle / total) * 100));
  cpuSample = now;
}, 1000);

/* ---------------- desktop item creation (right-click -> new) ---------------- */
function uniquePath(dir, base, ext) {
  for (let n = 0; n < 500; n++) {
    const name = n === 0 ? (base + ext) : (base + ' (' + (n + 1) + ')' + ext);
    const p = path.join(dir, name);
    if (!fs.existsSync(p)) return p;
  }
  return path.join(dir, base + '-' + Date.now() + ext);
}
const NEW_KINDS = {
  folder:   { base: '新建文件夹',        ext: '' },
  txt:      { base: '新建文本文档',      ext: '.txt' },
  md:       { base: '新建 Markdown 文档', ext: '.md' },
  bat:      { base: '新建批处理文件',    ext: '.bat' },
  docx:     { base: '新建 Word 文档',    ext: '.docx' }
};
function createDesktopItem(kind, name) {
  const dir = desktop.desktopPath;
  if (!dir || !fs.existsSync(dir)) return { ok: false, err: 'desktop path unavailable' };
  const spec = NEW_KINDS[kind];
  if (!spec) return { ok: false, err: 'unknown kind ' + kind };
  try {
    const target = uniquePath(dir, (name && String(name).trim()) || spec.base, spec.ext);
    if (kind === 'folder') fs.mkdirSync(target, { recursive: false });
    else fs.writeFileSync(target, '', 'utf8');
    log('created', kind, target);
    return { ok: true, path: target, name: path.basename(target) };
  } catch (e) {
    return { ok: false, err: e.message };
  }
}

/* ---------------- Lively Wallpaper mirror ---------------- */
let wpCache = { ts: 0, data: null };
function readLively() {
  if (Date.now() - wpCache.ts < 2000) return wpCache.data;
  wpCache = { ts: Date.now(), data: null };
  try {
    const base = path.join(process.env.LOCALAPPDATA || '', 'Lively Wallpaper');
    const layoutFile = path.join(base, 'WallpaperLayout.json');
    const arr = JSON.parse(fs.readFileSync(layoutFile, 'utf8'));
    const infoPath = Array.isArray(arr) && arr[0] ? arr[0].LivelyInfoPath : null;
    if (!infoPath) return wpCache.data;

    let dir = infoPath, infoFile = path.join(infoPath, 'LivelyInfo.json');
    try {
      if (fs.statSync(infoPath).isFile()) { infoFile = infoPath; dir = path.dirname(infoPath); }
    } catch (e) {}
    const info = JSON.parse(fs.readFileSync(infoFile, 'utf8'));

    const T = Number(info.Type);
    const kindMap = { 0: 'app', 1: 'web', 2: 'webaudio', 3: 'url', 7: 'video', 8: 'gif',
                      9: 'unityaudio', 10: 'videostream', 11: 'picture' };
    const kind = kindMap[T] || 'unknown';

    let file = info.FileName || '';
    // For webpage wallpapers we always load the folder's index.html.
    if (kind === 'web' || kind === 'webaudio') file = file || 'index.html';

    const embeddable = ['video', 'gif', 'picture', 'web', 'webaudio'].includes(kind);
    wpCache.data = {
      found: true, title: info.Title || '', type: T, kind,
      embeddable,
      url: embeddable && file ? ('/wallpaper/' + encodeURIComponent(file).replace(/%2F/gi, '/')) : null,
      dir
    };
    log('lively wallpaper:', kind, file);
    return wpCache.data;
  } catch (e) {
    return wpCache.data;
  }
}

/* ---------------- Edge kiosk ---------------- */
let edgeChild = null;
function findEdge() {
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
  ];
  for (const c of candidates) { try { if (fs.existsSync(c)) return c; } catch (e) {} }
  return null;
}
function runWinShell(env, timeout = 20000) {
  try {
    const script = fs.readFileSync(path.join(ROOT, 'tools', 'win-shell.ps1'), 'utf8');
    const b64 = Buffer.from(script, 'utf16le').toString('base64');
    const r = spawnSync('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', b64],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout, windowsHide: true,
        env: Object.assign({}, process.env, env) });
    const out = (r.stdout || '').trim();
    log('win-shell [' + (env.NEON_MODE || '?') + '] ->', out.slice(0, 200) || '(no output)');
    return out;
  } catch (e) {
    log('win-shell [' + (env.NEON_MODE || '?') + '] FAILED:', (e && e.message) || e);
    return '';
  }
}
function launchEdge(port) {
  const exe = findEdge();
  if (!exe) { log('Edge not found!'); return null; }
  fs.mkdirSync(EDGE_PROFILE, { recursive: true });
  const args = [
    '--kiosk',                          // boolean switch: URL must be a separate positional arg,
    'http://127.0.0.1:' + port + '/',   // --kiosk=<url> gets ignored and shows the InPrivate NTP
    '--edge-kiosk-type=fullscreen',
    '--user-data-dir=' + EDGE_PROFILE,
    '--no-first-run', '--no-default-browser-check',
    '--disable-extensions',
    '--no-proxy-server',                // loopback only -> bypass any system proxy
    '--use-fake-ui-for-media-stream',   // auto-accept mic / capture prompts
    // "system sound" pickup: getDisplayMedia() would otherwise pop a picker our
    // fullscreen kiosk cannot show. Auto-picking the whole screen makes Chromium
    // attach the Windows loopback (WASAPI) audio track, so the sound-bar can read
    // what the machine is actually playing - no dialog, no user gesture.
    '--auto-select-desktop-capture-source=Entire Screen',
    '--enable-usermedia-screen-capturing',
    '--autoplay-policy=no-user-gesture-required'
  ];
  edgeChild = spawn(exe, args, { stdio: 'ignore' });
  edgeChild.on('exit', code => {
    log('edge exited:', code);
    if (!shuttingDown) { log('edge closed by user - shutting down'); shutdown(); }
  });
  log('edge launched pid=' + edgeChild.pid);

  // Once the shell window exists: teach the daemon our pid, hide the taskbar
  // and drop the shell's topmost flag so normal apps can rise above it.
  setTimeout(async () => {
    await win.waitReady(20000);
    await win.send('shellpid', { pid: edgeChild.pid }, 4000);
    const tb = await win.send('taskbar', { show: false }, 6000);
    const ut = await win.send('untopmost', {}, 6000);
    log('shell prepare ->', JSON.stringify(tb), JSON.stringify(ut));
  }, 1500);

  return edgeChild;
}

async function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  log('shutting down...');

  // 1) restore the taskbar before anything else (fall back to the one-shot script)
  let restored = false;
  if (win.st.ready) {
    const r = await win.send('taskbar', { show: true }, 2500);
    restored = !!(r && r.ok);
  }
  if (!restored) runWinShell({ NEON_MODE: 'restore' }, 8000);

  // 2) kill the shell browser (by dedicated profile, to catch stragglers too)
  try { if (edgeChild) spawn('taskkill', ['/PID', String(edgeChild.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' }); } catch (e) {}
  runWinShell({ NEON_MODE: 'kill-edge', NEON_PROFILE: EDGE_PROFILE,
                NEON_SHELL_PID: String(edgeChild ? edgeChild.pid : 0) }, 12000);

  // 3) stop the helpers
  media.kill();
  win.kill();
  shell.kill();

  // 4) exit with a hard fallback so nothing lingers
  setTimeout(() => { try { process.exit(0); } catch (e) {} }, 400);
  setTimeout(() => { try { process.kill(process.pid, 'SIGKILL'); } catch (e) {} }, 2500);
}

/* ---------------- HTTP server ---------------- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.ogg': 'video/ogg', '.ogv': 'video/ogg',
  '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.m4a': 'audio/mp4', '.flac': 'audio/flac',
  '.gif': 'image/gif', '.webp': 'image/webp', '.bmp': 'image/bmp', '.avif': 'image/avif',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.otf': 'font/otf',
  '.wasm': 'application/wasm', '.txt': 'text/plain; charset=utf-8'
};
function sendJSON(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function readBody(req) {
  return new Promise(res => {
    let b = '';
    req.on('data', d => { b += d; if (b.length > 1e6) req.destroy(); });
    req.on('end', () => { try { res(JSON.parse(b || '{}')); } catch (e) { res({}); } });
    req.on('error', () => res({}));
  });
}

async function handle(req, res) {
  const u = new URL(req.url, 'http://127.0.0.1');
  const p = decodeURIComponent(u.pathname);

  /* ---- identity probe (used by the single-instance guard) ---- */
  if (p === '/api/ping') {
    return sendJSON(res, 200, { app: 'neon-shell', ok: true, port: HTTP_PORT, ts: Date.now() });
  }

  /* ---- desktop ---- */
  if (p === '/api/desktop') {
    if (Date.now() - desktop.ts > SCAN_INTERVAL && !scanning) scanDesktop();
    return sendJSON(res, 200, desktop);
  }
  if (p === '/api/scan') { scanDesktop(); return sendJSON(res, 200, { ok: true, queued: true }); }
  if (p === '/api/new') {
    const body = await readBody(req);
    const r = createDesktopItem(String(body.kind || 'folder'), body.name);
    if (r.ok) { scanDesktop(); setTimeout(() => scanDesktop(), 700); }
    return sendJSON(res, r.ok ? 200 : 400, r);
  }
  if (p === '/api/reveal') {
    const body = await readBody(req);
    if (!body.path) return sendJSON(res, 400, { ok: false });
    spawn('explorer.exe', ['/select,', body.path], { detached: true, stdio: 'ignore' }).unref();
    return sendJSON(res, 200, { ok: true });
  }
  if (p === '/api/open') {   // open a folder / file normally
    const body = await readBody(req);
    if (!body.path) return sendJSON(res, 400, { ok: false });
    spawn('explorer.exe', [body.path], { detached: true, stdio: 'ignore' }).unref();
    return sendJSON(res, 200, { ok: true });
  }

  /* ---- Explorer-like file verbs: cut / copy / paste / delete / rename / properties ---- */
  if (p === '/api/shellop') {
    const body = await readBody(req);
    const op = String(body.op || '');
    const OPS = ['clipinfo', 'copy', 'cut', 'paste', 'delete', 'rename', 'props', 'openwith'];
    if (!OPS.includes(op)) return sendJSON(res, 400, { ok: false, err: 'bad op' });

    if (!shell.st.ready) shell.revive();
    if (!(await shell.waitReady(6000))) {
      return sendJSON(res, 200, { ok: false, err: '文件服务未就绪，请稍后重试' });
    }
    const payload = {
      op,
      paths: Array.isArray(body.paths) ? body.paths.filter(x => typeof x === 'string') : [],
      path: typeof body.path === 'string' ? body.path : '',
      name: typeof body.name === 'string' ? body.name : '',
      target: typeof body.target === 'string' && body.target ? body.target : (desktop.desktopPath || '')
    };
    const r = await shell.send('fileop', payload, 25000);
    if (r && r.ok && ['paste', 'delete', 'rename'].includes(op)) {
      // Explorer copy/move runs async in its own process - refresh slightly later.
      setTimeout(scanDesktop, 1000);
      setTimeout(scanDesktop, 2600);
    }
    if (r && !r.ok) log('shellop', op, 'failed:', r.err || '');
    return sendJSON(res, 200, r || { ok: false, err: 'no response' });
  }

  /* ---- stats ---- */
  if (p === '/api/stats') {
    return sendJSON(res, 200, {
      cpu: Math.round(cpuPct),
      memTotal: os.totalmem(), memFree: os.freemem(),
      hostname: os.hostname(), uptime: os.uptime()
    });
  }

  /* ---- media (SMTC) ---- */
  if (p === '/api/media') return sendJSON(res, 200, mediaState);
  if (p === '/api/media-cmd') {
    const body = await readBody(req);
    const op = String(body.op || '');
    if (!['toggle', 'next', 'prev', 'stop'].includes(op)) return sendJSON(res, 400, { ok: false, err: 'bad op' });
    const r = await media.send(op, {}, 6000);
    return sendJSON(res, 200, r);
  }
  if (p === '/api/cover') {
    try {
      const buf = fs.readFileSync(COVER_FILE);
      const mime = (mediaState && mediaState.coverMime) || 'image/png';
      res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'no-store' });
      return res.end(buf);
    } catch (e) { res.writeHead(404); return res.end(); }
  }

  /* ---- window list / control (taskbar) ---- */
  if (p === '/api/winlist') {
    const r = await winListWithIcons();
    return sendJSON(res, 200, r);
  }
  if (p === '/api/winop') {
    const body = await readBody(req);
    const hwnd = Number(body.hwnd) || 0;
    const cmd = String(body.cmd || 'focus');
    if (!hwnd) return sendJSON(res, 400, { ok: false, err: 'no hwnd' });
    if (!['focus', 'min', 'max', 'close'].includes(cmd)) return sendJSON(res, 400, { ok: false, err: 'bad cmd' });
    const r = await win.send('winop', { hwnd, cmd }, 6000);
    return sendJSON(res, 200, r);
  }

  /* ---- tray (clock data: battery / network / volume) ---- */
  if (p === '/api/tray') {
    let r = null;
    try { if (await win.waitReady(2500)) r = await win.send('tray', {}, 5000); } catch (e) {}
    if (!r || !r.ok) return sendJSON(res, 200, { ok: false, err: (r && r.err) || 'daemon unavailable' });
    return sendJSON(res, 200, { ok: true, bat: r.bat, ac: !!r.ac, vol: r.vol,
                                mute: !!r.mute, kind: r.kind || 'off', net: r.net || '', ip: r.ip || '' });
  }
  if (p === '/api/volset') {
    const body = await readBody(req);
    const cmd = { };
    if (body.level !== undefined) cmd.level = Math.max(0, Math.min(1, Number(body.level) || 0));
    if (body.mute !== undefined)  cmd.mute  = !!body.mute;
    let r = null;
    try { if (await win.waitReady(2500)) r = await win.send('volset', cmd, 5000); } catch (e) {}
    if (!r || !r.ok) return sendJSON(res, 200, { ok: false, err: (r && r.err) || 'daemon unavailable' });
    return sendJSON(res, 200, { ok: true, vol: r.vol, mute: !!r.mute });
  }

  /* ---- launch ---- */
  if (p === '/api/launch') {
    const body = await readBody(req);
    if (!body.path) return sendJSON(res, 400, { ok: false, err: 'no path' });
    sendJSON(res, 200, { ok: true, queued: true });   // answer first, do the slow part after
    (async () => {
      if (!win.st.ready) win.revive();               // daemon died? bring it back
      if (await win.waitReady(4000)) {
        const r = await win.send('launch', { target: body.path, isDir: !!body.isDir, wait: 8 }, 20000);
        if (!r || !r.ok) log('launch FAILED', JSON.stringify(body.path), JSON.stringify(r));
        else if (r.note === 'no window captured') log('launch ok but no window', JSON.stringify(body.path), r.how || '');
      } else {
        // daemon unavailable -> one-shot fallback
        runWinShell({ NEON_MODE: 'launch', NEON_TARGET: body.path,
                      NEON_ISDIR: body.isDir ? '1' : '0', NEON_PROFILE: EDGE_PROFILE,
                      NEON_SHELL_PID: String(edgeChild ? edgeChild.pid : 0),
                      NEON_WAIT: '12' }, 25000);
      }
    })().catch(e => log('launch exception:', (e && e.message) || e));
    return;
  }

  /* ---- wallpaper (Lively mirror) ---- */
  if (p === '/api/wallpaper') {
    const w = readLively();
    return sendJSON(res, 200, w || { found: false });
  }
  if (p.startsWith('/wallpaper/') && !p.includes('..')) {
    const wp = readLively();
    if (!wp || !wp.dir) { res.writeHead(404); return res.end(); }
    let rel = p.slice('/wallpaper/'.length);
    const baseDir = path.normalize(wp.dir);
    const full = path.normalize(path.join(baseDir, rel));
    if (!full.startsWith(baseDir)) { res.writeHead(403); return res.end(); }
    return serveMedia(res, req, full);
  }

  /* ---- shell control ---- */
  if (p === '/api/exit') { sendJSON(res, 200, { ok: true }); setTimeout(shutdown, 150); return; }

  /* ---- static ---- */
  if (p === '/') return serveFile(res, path.join(PUBLIC, 'index.html'));
  if (p.startsWith('/icon/') && p.includes('.') && !p.includes('..')) {
    return serveFile(res, path.join(ICON_DIR, path.basename(p)), true);
  }
  if (p.startsWith('/asset/') && !p.includes('..')) {
    return serveFile(res, path.join(PUBLIC, path.basename(p)));
  }
  res.writeHead(404); res.end('not found');
}

function serveFile(res, file, cacheable) {
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404); return res.end(); }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': cacheable ? 'public, max-age=604800' : 'no-cache'
    });
    res.end(buf);
  });
}

// Range-aware streaming (needed for <video> wallpaper playback / seeking).
function serveMedia(res, req, file) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end(); }
    const ext = path.extname(file).toLowerCase();
    const mime = MIME[ext] || 'application/octet-stream';
    const range = req.headers.range;
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      let start = m && m[1] ? parseInt(m[1], 10) : 0;
      let end = m && m[2] ? parseInt(m[2], 10) : st.size - 1;
      if (isNaN(start) || start < 0) start = 0;
      if (isNaN(end) || end >= st.size) end = st.size - 1;
      if (start > end) { res.writeHead(416); return res.end(); }
      res.writeHead(206, {
        'Content-Type': mime,
        'Content-Range': 'bytes ' + start + '-' + end + '/' + st.size,
        'Accept-Ranges': 'bytes',
        'Content-Length': end - start + 1,
        'Cache-Control': 'no-store'
      });
      fs.createReadStream(file, { start, end }).pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Type': mime, 'Content-Length': st.size,
        'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store'
      });
      fs.createReadStream(file).pipe(res);
    }
  });
}

/* ---------------- main ---------------- */
(async () => {
  log('==== NEON SHELL starting ====');

  await ensureSingleInstance();     // never run two half-broken instances at once
  scanDesktop();

  const port = await pickPort();
  HTTP_PORT  = port;
  MEDIA_PORT = port + 9;            // daemon ports follow the HTTP port -> no clash
  WIN_PORT   = port + 10;
  SHELL_PORT = port + 11;
  log('ports: http=' + HTTP_PORT + ' media=' + MEDIA_PORT + ' win=' + WIN_PORT + ' shell=' + SHELL_PORT);

  freeDaemonPorts();                // clear orphaned daemons from a crashed run
  media.start();
  mediaPollLoop().catch(e => log('media poll loop died', e));
  win.start();
  shell.start();

  const server = http.createServer((req, res) => { handle(req, res).catch(e => { try { sendJSON(res, 500, { ok: false, err: e.message }); } catch (x) {} }); });
  await new Promise(r => server.listen(port, '127.0.0.1', r));
  log('UI served at http://127.0.0.1:' + port + '/');

  if (process.env.NEON_NO_EDGE) {
    log('NEON_NO_EDGE set - skipping kiosk launch (test mode)');
  } else {
    launchEdge(port);
  }

  // watchdog: exit when the launching parent (vbs) dies
  if (process.env.NEON_PARENT_PID) {
    const ppid = parseInt(process.env.NEON_PARENT_PID, 10);
    setInterval(() => {
      try { process.kill(ppid, 0); } catch (e) { log('parent gone - exit'); process.exit(0); }
    }, 5000);
  }
})();
