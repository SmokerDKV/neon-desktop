# NEON SHELL - window daemon (persistent)
# Serves window queries / app launch / taskbar control over a loopback TCP line protocol.
# The expensive Add-Type (C# compile) happens ONCE at startup, so every later
# command answers in a few milliseconds.
# Protocol: one request JSON per line  ->  one response JSON per line.
# Emits "READY <port>" on stdout once the listener is up.

[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$CSharp = @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

public class NSWin
{
    public delegate bool EnumProc(IntPtr h, IntPtr lp);

    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr lp);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int idx);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr h);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr FindWindow(string cls, string win);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
    [DllImport("user32.dll")] public static extern void SwitchToThisWindow(IntPtr h, bool alt);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int attr, out int val, int sz);
    [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder buf, ref int size);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

    // Full path of the executable owning `pid` (no WMI - fast, works for elevated apps too).
    public static string ExePathOf(int pid)
    {
        IntPtr h = OpenProcess(0x1000, false, pid);   // PROCESS_QUERY_LIMITED_INFORMATION
        if (h == IntPtr.Zero) return "";
        try
        {
            var sb = new StringBuilder(1024);
            int sz = sb.Capacity;
            if (QueryFullProcessImageName(h, 0, sb, ref sz)) return sb.ToString();
            return "";
        }
        finally { CloseHandle(h); }
    }

    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }

    static readonly IntPtr HWND_TOP       = IntPtr.Zero;
    static readonly IntPtr HWND_TOPMOST   = new IntPtr(-1);
    static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);
    const uint SWP_NOSIZE = 0x1, SWP_NOMOVE = 0x2, SWP_NOACTIVATE = 0x10;

    const int GWL_EXSTYLE      = -20;
    const int WS_EX_TOOLWINDOW = 0x00000080;
    const int WS_EX_APPWINDOW  = 0x00040000;
    const int WS_EX_TOPMOST    = 0x00000008;
    const uint GW_OWNER        = 4;
    const int DWMWA_CLOAKED    = 14;

    public static string Text(IntPtr h) { var sb = new StringBuilder(600); GetWindowText(h, sb, 600); return sb.ToString(); }
    public static string Cls(IntPtr h)  { var sb = new StringBuilder(256); GetClassName(h, sb, 256); return sb.ToString(); }
    public static int  PidOf(IntPtr h)  { uint p; GetWindowThreadProcessId(h, out p); return (int)p; }
    public static long Area(IntPtr h)   { RECT r; if (!GetWindowRect(h, out r)) return 0; long w = r.R - r.L, hh = r.B - r.T; if (w <= 0 || hh <= 0) return 0; return w * hh; }
    public static bool IsCloaked(IntPtr h) { int v; try { if (DwmGetWindowAttribute(h, DWMWA_CLOAKED, out v, 4) == 0) return v != 0; } catch {} return false; }
    public static bool IsTopmost(IntPtr h) { return (GetWindowLong(h, GWL_EXSTYLE) & WS_EX_TOPMOST) != 0; }
    public static bool IsTool(IntPtr h)    { return (GetWindowLong(h, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) != 0; }
    public static bool HasOwner(IntPtr h)  { return GetWindow(h, GW_OWNER) != IntPtr.Zero; }
    public static bool IsMinimized(IntPtr h) { return IsIconic(h); }
    public static bool IsMaximized(IntPtr h) { return IsZoomed(h); }

    // Taskbar-style filter: visible, titled, non-tool windows.
    // (UWP / WinUI apps like Notepad carry an owner window, so we do NOT
    //  require "no owner" here - otherwise they would never show up.)
    public static bool IsAppWindow(IntPtr h)
    {
        if (!IsWindowVisible(h)) return false;
        if (IsCloaked(h)) return false;
        if (IsTool(h)) return false;
        if (Text(h).Trim().Length == 0) return false;
        string c = Cls(h);
        if (c == "Progman" || c == "WorkerW" || c == "Shell_TrayWnd" ||
            c == "Shell_SecondaryTrayWnd" || c == "ApplicationManager_DesktopShellWindow") return false;
        if (c.StartsWith("Windows.UI.Core.CoreWindow")) return false;
        return true;
    }

    // EnumWindows walks windows in z-order (top-most first) == most recently used order.
    public static List<IntPtr> AppWindows()
    {
        var res = new List<IntPtr>();
        EnumWindows((h, lp) => { if (IsAppWindow(h)) res.Add(h); return true; }, IntPtr.Zero);
        return res;
    }
    public static List<IntPtr> AllVisible()
    {
        var res = new List<IntPtr>();
        EnumWindows((h, lp) => { if (IsWindowVisible(h)) res.Add(h); return true; }, IntPtr.Zero);
        return res;
    }
    public static List<IntPtr> WindowsOfPid(int pid, long minArea)
    {
        var res = new List<IntPtr>();
        EnumWindows((h, lp) => {
            if (PidOf(h) == pid && IsWindowVisible(h) && Area(h) > minArea) res.Add(h);
            return true;
        }, IntPtr.Zero);
        return res;
    }

    public static void Activate(IntPtr h)
    {
        if (IsIconic(h)) ShowWindow(h, 9);   // SW_RESTORE
        ShowWindow(h, 5);                    // SW_SHOW
        SwitchToThisWindow(h, true);
        SetForegroundWindow(h);
        SetWindowPos(h, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    }
    public static void Minimize(IntPtr h) { ShowWindow(h, 6); }              // SW_MINIMIZE
    public static void Maximize(IntPtr h) { ShowWindow(h, 3); }              // SW_MAXIMIZE
    public static void Close(IntPtr h)    { PostMessage(h, 0x10, IntPtr.Zero, IntPtr.Zero); }
    public static void MakeTopmost(IntPtr h)   { SetWindowPos(h, HWND_TOPMOST,   0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); }
    public static void ClearTopmost(IntPtr h)  { SetWindowPos(h, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); }
}

// High resolution shell icon extractor (shared by desktop scan + taskbar icons).
public static class NeonIcon
{
    const uint SHGFI_SYSICONINDEX = 0x000004000;
    const uint SHGFI_LARGEICON    = 0x000000000;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct SHFILEINFO
    {
        public IntPtr hIcon;
        public int    iIcon;
        public uint   dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]  public string szTypeName;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct IMAGELISTDRAWPARAMS
    {
        public int    cbSize;
        public IntPtr himl;
        public int    i;
        public IntPtr hdcDst;
        public int    x, y, cx, cy, xBitmap, yBitmap;
        public int    rgbBk, rgbFg, fStyle, dwRop;
    }

    [ComImport, Guid("46EB5926-582E-4017-9FDF-E8998DAA0950"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IImageList
    {
        [PreserveSig] int Add(IntPtr hbmImage, IntPtr hbmMask, ref int pi);
        [PreserveSig] int ReplaceIcon(int i, IntPtr hicon, ref int pi);
        [PreserveSig] int SetOverlayImage(int iImage, int iOverlay);
        [PreserveSig] int Replace(int i, IntPtr hbmImage, IntPtr hbmMask);
        [PreserveSig] int AddMasked(IntPtr hbmImage, int crMask, ref int pi);
        [PreserveSig] int Draw(ref IMAGELISTDRAWPARAMS pimldp);
        [PreserveSig] int Remove(int i);
        [PreserveSig] int GetIcon(int i, int flags, ref IntPtr picon);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    static extern IntPtr SHGetFileInfo(string pszPath, uint dwFileAttributes, ref SHFILEINFO psfi, uint cbFileInfo, uint uFlags);

    [DllImport("shell32.dll")]
    static extern int SHGetImageList(int iImageList, ref Guid riid, out IImageList ppv);

    [DllImport("user32.dll")]
    static extern bool DestroyIcon(IntPtr hIcon);

    // Renders the shell icon of `path` into a square PNG at `outPng`.
    // Prefers the 256px "jumbo" image list, falls back to the large icon.
    public static string Extract(string path, string outPng, int size, out int gotW, out int gotH)
    {
        gotW = 0; gotH = 0;
        IntPtr hIcon = IntPtr.Zero;
        IImageList list = null;
        string src = "?";
        try
        {
            var shfi = new SHFILEINFO();
            IntPtr ret = SHGetFileInfo(path, 0, ref shfi, (uint)Marshal.SizeOf(typeof(SHFILEINFO)),
                                       SHGFI_SYSICONINDEX | SHGFI_LARGEICON);
            if (ret == IntPtr.Zero) return "SHGETFILEINFO_ZERO";

            Guid iid = new Guid("46EB5926-582E-4017-9FDF-E8998DAA0950");
            int hr = SHGetImageList(4, ref iid, out list);   // SHIL_JUMBO = 4 -> 256px
            if (hr == 0 && list != null)
            {
                if (list.GetIcon(shfi.iIcon, 0x1, ref hIcon) == 0 && hIcon != IntPtr.Zero)
                    src = "jumbo";
            }
            if (hIcon == IntPtr.Zero)
            {
                var f2 = new SHFILEINFO();
                SHGetFileInfo(path, 0, ref f2, (uint)Marshal.SizeOf(typeof(SHFILEINFO)), 0x100 | SHGFI_LARGEICON);
                hIcon = f2.hIcon;
                src = "large";
            }
            if (hIcon == IntPtr.Zero) return "NO_ICON";

            using (var ico = System.Drawing.Icon.FromHandle(hIcon))
            {
                gotW = ico.Width; gotH = ico.Height;
                using (var bmp = new System.Drawing.Bitmap(size, size, System.Drawing.Imaging.PixelFormat.Format32bppArgb))
                {
                    using (var g = System.Drawing.Graphics.FromImage(bmp))
                    {
                        g.Clear(System.Drawing.Color.Transparent);
                        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                        g.PixelOffsetMode   = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                        g.DrawIcon(ico, new System.Drawing.Rectangle(0, 0, size, size));
                    }
                    bmp.Save(outPng, System.Drawing.Imaging.ImageFormat.Png);
                }
            }
            return "OK:" + src;
        }
        catch (Exception ex) { return "ERR:" + ex.Message; }
        finally
        {
            if (hIcon != IntPtr.Zero) { try { DestroyIcon(hIcon); } catch {} }
            if (list  != null)        { try { Marshal.ReleaseComObject(list); } catch {} }
        }
    }
}
// Battery (kernel32 - no WinForms dependency).
[StructLayout(LayoutKind.Sequential)]
public struct NPOWER { public byte AC; public byte Flag; public byte Pct; public byte Rsv; public int Secs; public int Full; }
public static class NSTray
{
    [DllImport("kernel32.dll")] public static extern bool GetSystemPowerStatus(out NPOWER s);
    public static int BatteryPct()
    {
        NPOWER s;
        if (!GetSystemPowerStatus(out s)) return -1;
        if (s.Pct >= 1 && s.Pct <= 100) return s.Pct;   // 255/0 = unknown
        return -1;
    }
    public static bool AcOnline() { NPOWER s; if (!GetSystemPowerStatus(out s)) return false; return s.AC == 1; }
}

// Master audio endpoint volume (Core Audio COM - works on every Windows without extra deps).
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
class NSMMEnumerator { }

[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface NSIMMEnumerator
{
    [PreserveSig] int EnumAudioEndpoints(uint flow, uint mask, out IntPtr list);
    [PreserveSig] int GetDefaultAudioEndpoint(uint flow, uint role, out NSIMMDevice dev);
}

[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface NSIMMDevice
{
    [PreserveSig] int Activate(ref Guid iid, uint clsCtx, IntPtr param, [MarshalAs(UnmanagedType.Interface)] out NSIAudioEndpoint epv);
}

[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface NSIAudioEndpoint
{
    [PreserveSig] int RegisterControlChangeNotify(IntPtr n);
    [PreserveSig] int UnregisterControlChangeNotify(IntPtr n);
    [PreserveSig] int GetChannelCount(out uint n);
    [PreserveSig] int SetMasterVolumeLevel(float db, ref Guid ctx);
    [PreserveSig] int SetMasterVolumeLevelScalar(float lvl, ref Guid ctx);
    [PreserveSig] int GetMasterVolumeLevel(out float db);
    [PreserveSig] int GetMasterVolumeLevelScalar(out float lvl);
    [PreserveSig] int SetChannelVolumeLevel(uint ch, float db, ref Guid ctx);
    [PreserveSig] int SetChannelVolumeLevelScalar(uint ch, float lvl, ref Guid ctx);
    [PreserveSig] int GetChannelVolumeLevel(uint ch, out float db);
    [PreserveSig] int GetChannelVolumeLevelScalar(uint ch, out float lvl);
    [PreserveSig] int SetMute(uint mute, ref Guid ctx);      // BOOL = 4 bytes (C# bool would marshal as 2-byte VARIANT_BOOL)
    [PreserveSig] int GetMute(out uint mute);
}

public static class NSAudio
{
    static readonly Guid IID_EP = new Guid("5CDF2C82-841E-4546-9722-0CF74078229A");
    static NSIAudioEndpoint _ep;

    static NSIAudioEndpoint Ep()
    {
        if (_ep != null) return _ep;
        var en = (NSIMMEnumerator)(object)new NSMMEnumerator();
        NSIMMDevice dev;
        int hr = en.GetDefaultAudioEndpoint(0, 1, out dev);   // eRender, eMultimedia
        if (hr != 0) throw new Exception("GetDefaultAudioEndpoint hr=0x" + hr.ToString("X"));
        Guid g = IID_EP;
        hr = dev.Activate(ref g, 1, IntPtr.Zero, out _ep);    // CLSCTX_INPROC_SERVER
        if (hr != 0) throw new Exception("Activate hr=0x" + hr.ToString("X"));
        return _ep;
    }
    static readonly Guid EmptyCtx = new Guid("00000000-0000-0000-0000-000000000000");

    public static float Level() { float f; int hr = Ep().GetMasterVolumeLevelScalar(out f); if (hr != 0) throw new Exception("hr=0x" + hr.ToString("X")); return f; }
    public static bool   Mute() { uint m; int hr = Ep().GetMute(out m); if (hr != 0) throw new Exception("hr=0x" + hr.ToString("X")); return m != 0; }
    public static void SetLevel(float lvl)
    {
        if (lvl < 0) lvl = 0; if (lvl > 1) lvl = 1;
        Guid g = EmptyCtx; int hr = Ep().SetMasterVolumeLevelScalar(lvl, ref g);
        if (hr != 0) throw new Exception("hr=0x" + hr.ToString("X"));
    }
    public static void SetMute(bool m) { Guid g = EmptyCtx; int hr = Ep().SetMute(m ? 1u : 0u, ref g); if (hr != 0) throw new Exception("hr=0x" + hr.ToString("X")); }
}
'@

Add-Type -TypeDefinition $CSharp -ReferencedAssemblies 'System.Drawing' -ErrorAction Stop

$port     = [int]$env:NEON_WIN_PORT
$Profile  = $env:NEON_PROFILE
$ShellPid = [int]$env:NEON_SHELL_PID

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
$listener.Start()
[Console]::Out.WriteLine('READY ' + $port)
[Console]::Out.Flush()

$client = $listener.AcceptTcpClient()
$stream = $client.GetStream()
$reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
$writer = New-Object System.IO.StreamWriter($stream, (New-Object System.Text.UTF8Encoding($false)))
$writer.AutoFlush = $true

# Cache the set of shell (Edge) pids - refreshing it is the only slow call here,
# and it only has to happen every few seconds.
$script:shellPids    = @()
$script:shellPidsTs  = [DateTime]::MinValue
function Get-ShellPids {
    $now = Get-Date
    if (($now - $script:shellPidsTs).TotalSeconds -lt 6 -and $script:shellPids.Count -gt 0) {
        return $script:shellPids
    }
    $r = @()
    if ($ShellPid -gt 0) { $r += $ShellPid }
    if ($Profile) {
        try {
            $r += @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
                    Where-Object { $_.CommandLine -like ('*' + $Profile + '*') } |
                    Select-Object -ExpandProperty ProcessId)
        } catch {}
    }
    $script:shellPids   = @($r | Sort-Object -Unique)
    $script:shellPidsTs = $now
    return $script:shellPids
}

function Get-WinList {
    $ex  = Get-ShellPids
    $out = New-Object System.Collections.ArrayList
    foreach ($h in [NSWin]::AppWindows()) {
        $wp = [NSWin]::PidOf($h)
        if ($ex -contains $wp) { continue }
        $t = [NSWin]::Text($h)
        if ($t -like '*NEON SHELL*') { continue }
        $c = [NSWin]::Cls($h)
        if ($c -eq 'Progman' -or $c -eq 'WorkerW' -or $c -like 'Shell_*') { continue }
        $null = $out.Add([ordered]@{
            h   = [int64]$h
            pid = $wp
            t   = $t
            c   = $c
            a   = [int64][NSWin]::Area($h)
            min = [bool][NSWin]::IsMinimized($h)
            max = [bool][NSWin]::IsMaximized($h)
            exe = [NSWin]::ExePathOf($wp)
        })
    }
    return $out
}

function Get-Dump {
    $out = New-Object System.Collections.ArrayList
    foreach ($h in [NSWin]::AllVisible()) {
        $null = $out.Add([ordered]@{
            h = [int64]$h; pid = [NSWin]::PidOf($h); t = [NSWin]::Text($h); c = [NSWin]::Cls($h)
            a = [int64][NSWin]::Area($h); cloak = [bool][NSWin]::IsCloaked($h)
            tool = [bool][NSWin]::IsTool($h); own = [bool][NSWin]::HasOwner($h)
            app = [bool][NSWin]::IsAppWindow($h)
        })
    }
    return $out
}

# Launch one desktop item. Some targets make Start-Process throw
# ("无法完全运行此命令，因为系统找不到所需的全部信息" - typically shortcuts to
# UWP / elevated / shell-namespace apps), so we cascade through three methods
# and only report failure when all three are exhausted.
function Start-Target($target, $isDir) {
    $errs = @()

    # 方式 1 - Start-Process（能拿到进程句柄，便于随后定位它自己的窗口）
    try {
        if ($isDir) { $p = Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $target + '"') -PassThru -ErrorAction Stop }
        else        { $p = Start-Process -FilePath $target -PassThru -ErrorAction Stop }
        if ($p) { return @{ proc = $p; how = 'Start-Process' } }
        return @{ proc = $null; how = 'Start-Process'; note = 'no handle' }
    } catch { $errs += ('Start-Process: ' + $_.Exception.Message) }

    # 方式 2 - 直接 ShellExecute（语义等同资源管理器里双击）
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName        = $target
        $psi.UseShellExecute = $true
        $p2 = [System.Diagnostics.Process]::Start($psi)
        if ($p2) { return @{ proc = $p2; how = 'ShellExecute' } }
        return @{ proc = $null; how = 'ShellExecute'; note = 'no handle' }
    } catch { $errs += ('ShellExecute: ' + $_.Exception.Message) }

    # 方式 3 - cmd 的 start（最贴近用户手动双击的行为）
    # 只对真实存在的路径使用，避免对不存在的目标"假成功"。
    $exists = $false
    try { $exists = Test-Path -LiteralPath $target } catch {}
    if ($exists) {
        try {
            Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', 'start', '""', ('"' + $target + '"') `
                          -WindowStyle Hidden -ErrorAction Stop
            return @{ proc = $null; how = 'cmd-start'; note = 'started via cmd' }
        } catch { $errs += ('cmd-start: ' + $_.Exception.Message) }
    } else {
        $errs += 'target not found: ' + $target
    }

    return @{ proc = $null; how = 'failed'; err = ($errs -join ' | ') }
}

function Invoke-Launch($target, $isDir, $waitSec) {
    if (-not $target) { return @{ ok = $false; err = 'no target' } }

    $before = @{}
    foreach ($h in [NSWin]::AllVisible()) { $before[[int64]$h] = $true }

    $st = Start-Target $target $isDir
    if ($st.err) { return @{ ok = $false; err = $st.err; target = $target } }
    $proc = $st.proc

    $tpid = 0
    if ($proc) { try { $tpid = [int]$proc.Id } catch { $tpid = 0 } }

    $hit          = [IntPtr]::Zero
    $deadline     = (Get-Date).AddSeconds($waitSec)
    $pids         = @()
    if ($tpid -gt 0) { $pids = @($tpid) }
    $childChecked = $false

    while ((Get-Date) -lt $deadline) {
        $cands = @()
        foreach ($p in $pids) {
            foreach ($h in [NSWin]::WindowsOfPid([int]$p, 2000)) { $cands += $h }
        }
        if ($cands.Count -eq 0 -and $tpid -gt 0 -and -not $childChecked) {
            $childChecked = $true
            try { $pids += @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$tpid" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessId) } catch {}
        }
        if ($cands.Count -eq 0) {
            # fallback: any newly appeared window that is not ours
            foreach ($h in [NSWin]::AllVisible()) {
                if (-not $before.ContainsKey([int64]$h)) {
                    $c = [NSWin]::Cls($h)
                    if ($c -notlike 'Shell_*' -and $c -notlike 'Chrome_WidgetWin*' -and [NSWin]::Area($h) -gt 2000) { $cands += $h }
                }
            }
        }
        if ($cands.Count -gt 0) {
            $best = 0
            foreach ($h in $cands) { if ([NSWin]::Area($h) -gt $best) { $best = [NSWin]::Area($h); $hit = $h } }
            break
        }
        Start-Sleep -Milliseconds 90
    }

    if ($hit -ne [IntPtr]::Zero) {
        [NSWin]::Activate($hit)
        return @{ ok = $true; pid = $tpid; how = $st.how; hwnd = [int64]$hit; title = [NSWin]::Text($hit); cls = [NSWin]::Cls($hit) }
    }
    return @{ ok = $true; pid = $tpid; how = $st.how; hwnd = 0; title = ''; note = 'no window captured' }
}

function Invoke-WinOp($hwnd, $op) {
    $h = [IntPtr][int64]$hwnd
    if (-not [NSWin]::IsWindow($h)) { return @{ ok = $false; err = 'invalid window' } }
    switch ($op) {
        'focus' { [NSWin]::Activate($h) }
        'min'   { [NSWin]::Minimize($h) }
        'max'   { [NSWin]::Maximize($h) }
        'close' { [NSWin]::Close($h) }
        default { return @{ ok = $false; err = ('bad op ' + $op) } }
    }
    return @{ ok = $true }
}

function Set-Taskbar([bool]$show) {
    $n = 0
    $cmd = 0; if ($show) { $cmd = 5 }   # SW_HIDE / SW_SHOW
    foreach ($name in @('Shell_TrayWnd', 'Shell_SecondaryTrayWnd')) {
        $h = [NSWin]::FindWindow($name, $null)
        if ($h -ne [IntPtr]::Zero) { [void][NSWin]::ShowWindow($h, $cmd); $n++ }
    }
    return $n
}

function Invoke-Untopmost {
    $cleared = 0
    foreach ($p in (Get-ShellPids)) {
        foreach ($h in [NSWin]::WindowsOfPid([int]$p, 0)) {
            if ([NSWin]::IsTopmost($h)) { [NSWin]::ClearTopmost($h); $cleared++ }
        }
    }
    return $cleared
}

# ---- tray (network info is slow-ish, cache it for 30s) ----
$script:netCache   = $null
$script:netCacheTs = [DateTime]::MinValue

function Get-NetInfo {
    $now = Get-Date
    if ($script:netCache -ne $null -and ($now - $script:netCacheTs).TotalSeconds -lt 30) { return $script:netCache }

    $info = @{ kind = 'off'; name = ''; ssid = ''; ip = '' }
    try {
        $ad = Get-NetAdapter -ErrorAction SilentlyContinue |
              Where-Object { $_.Status -eq 'Up' } |
              Sort-Object -Property ifIndex | Select-Object -First 1
        if ($ad) {
            $info.kind = if ($ad.MediaType -like '*802.11*') { 'wifi' } else { 'lan' }
            $info.name = [string]$ad.Name
            try {
                $ipOb = Get-NetIPAddress -InterfaceIndex $ad.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                        Where-Object { $_.IPAddress -notlike '169.254.*' } | Select-Object -First 1
                if ($ipOb) { $info.ip = [string]$ipOb.IPAddress }
            } catch {}
        }
    } catch {}
    if ($info.kind -eq 'wifi') {
        try {
            $out = & netsh.exe wlan show interfaces 2>$null
            foreach ($ln in $out) {
                if ($ln -match '^\s*SSID\s*:\s*(.+)$') { $info.ssid = $Matches[1].Trim(); break }
            }
        } catch {}
        if ($info.ssid) { $info.name = $info.ssid }
    }
    $script:netCache   = $info
    $script:netCacheTs = $now
    return $info
}

function Get-Tray {
    $t = @{}
    try { $t.bat = [NSTray]::BatteryPct() } catch { $t.bat = -1 }
    try { $t.ac  = [NSTray]::AcOnline() }  catch { $t.ac  = $false }
    try { $t.vol = [int][Math]::Round([NSAudio]::Level() * 100) } catch { $t.vol = -1 }
    try { $t.mute = [NSAudio]::Mute() } catch { $t.mute = $false }
    try { $n = Get-NetInfo; $t.kind = $n.kind; $t.net = $n.name; $t.ip = $n.ip } catch { $t.kind = 'off'; $t.net = ''; $t.ip = '' }
    return $t
}

while ($true) {
    $line = $reader.ReadLine()
    if ($line -eq $null) { break }
    if ($line.Trim().Length -eq 0) { continue }
    $req = $null
    try { $req = ConvertFrom-Json $line } catch { continue }

    $id = 0
    try { $id = [int]$req.id } catch {}
    $op = [string]$req.op

    try {
        switch ($op) {
            'ping'    { $resp = @{ id = $id; ok = $true; pong = $true } }
            'winlist' { $resp = @{ id = $id; ok = $true; wins = (Get-WinList) } }
            'dump'    { $resp = @{ id = $id; ok = $true; wins = (Get-Dump) } }
            'launch'  {
                $w = 8
                try { $w = [int]$req.wait } catch {}
                $r = Invoke-Launch ([string]$req.target) ([bool]$req.isDir) $w
                $resp = @{ id = $id; ok = $r.ok }
                if ($r.err)   { $resp.err   = $r.err }
                if ($r.how)   { $resp.how   = $r.how }
                if ($r.hwnd)  { $resp.hwnd  = $r.hwnd }
                if ($r.pid)   { $resp.pid   = $r.pid }
                if ($r.title) { $resp.title = $r.title }
                if ($r.note)  { $resp.note  = $r.note }
            }
            'winop'   {
                $r = Invoke-WinOp ([int64]$req.hwnd) ([string]$req.cmd)
                $resp = @{ id = $id; ok = $r.ok }
                if ($r.err) { $resp.err = $r.err }
            }
            'taskbar' {
                $n = Set-Taskbar ([bool]$req.show)
                $resp = @{ id = $id; ok = $true; count = $n }
            }
            'untopmost' {
                $n = Invoke-Untopmost
                $resp = @{ id = $id; ok = $true; cleared = $n }
            }
            'tray' {
                $r = Get-Tray
                $resp = @{ id = $id; ok = $true }
                foreach ($k in $r.Keys) { $resp[$k] = $r[$k] }
            }
            'volset' {
                $hasLvl = $null -ne $req.level
                $hasMute = $null -ne $req.mute
                if ($hasLvl) {
                    $lv = [float]$req.level
                    if ($lv -lt 0) { $lv = 0 } ; if ($lv -gt 1) { $lv = 1 }
                    [NSAudio]::SetLevel($lv)
                    # unmute when the user drags the slider (matches Windows behaviour)
                    if ([NSAudio]::Mute() -and $lv -gt 0) { [NSAudio]::SetMute($false) }
                }
                if ($hasMute) { [NSAudio]::SetMute([bool]$req.mute) }
                $resp = @{ id = $id; ok = $true;
                           vol  = [int][Math]::Round([NSAudio]::Level() * 100) }
                try { $resp.mute = [NSAudio]::Mute() } catch {}
            }
            'shellpid' {
                $script:ShellPid   = [int]$req.pid
                $script:shellPids  = @()
                $script:shellPidsTs = [DateTime]::MinValue
                $resp = @{ id = $id; ok = $true }
            }
            'icon' {
                $src = [string]$req.path
                $dst = [string]$req.out
                if (-not $src -or -not $dst) { $resp = @{ id = $id; ok = $false; err = 'path+out required' } }
                else {
                    $w = 0; $h = 0
                    $r = [NeonIcon]::Extract($src, $dst, 128, [ref]$w, [ref]$h)
                    $resp = @{ id = $id; ok = ($r -like 'OK*'); src = $r; w = $w; h = $h }
                }
            }
            default { $resp = @{ id = $id; ok = $false; err = ('unknown op ' + $op) } }
        }
    } catch {
        $resp = @{ id = $id; ok = $false; err = $_.Exception.Message }
    }
    $writer.WriteLine(($resp | ConvertTo-Json -Compress -Depth 4))
}
